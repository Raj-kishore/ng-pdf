import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as Chart from 'chart.js';
import { ApiCommonService } from 'src/app/services/api-common.service';
import { environment } from 'src/environments/environment';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { summaryFileName } from '@angular/compiler/src/aot/util';
import { ObjectUnsubscribedError } from 'rxjs';
import * as pluginLabels from 'chartjs-plugin-labels';
import 'chartjs-plugin-labels';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { assessmentTable } from '../../../../models/assessment';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { ViewResultComponent } from 'src/app/modules/view-result/components/view-result/view-result.component';
import { Observable, Subject } from 'rxjs';
import { action } from '../../../../models/account';
import { CancelPopupComponent } from '../cancel-popup/cancel-popup.component';
import * as Highcharts from "highcharts";
import { NotificationService } from '../../../../services/notification.service';
import { EditAssessmentComponent } from '../edit-assessment/edit-assessment.component';
import { saveAs } from "file-saver";
import { ExportService } from "../../../../services/export.service";
import { PreviewReportComponent } from '../preview-report/preview-report.component';


const MIME_TYPES = {
    xlxs: "application/vnc.openxmlformats-officedocument.spreadsheetxml.sheet",
};
@Component({
    selector: 'app-user-dashboard',
    templateUrl: './user-dashboard.component.html',
    styleUrls: ['./user-dashboard.component.css']
})



export class UserDashboardComponent implements OnInit {
    @ViewChild("container", { read: ElementRef }) container: ElementRef;

    isDisabledReset: boolean = false;
    currentSBU = '';
    currentBU = '';
    currentMU = '';
    resetTrigger: boolean = false;

    accountid: any;

    fetch_currentSBUspocSBUId: any;
    fetch_currentBUspocBUId: any;

    timer: any;
    doSpin: boolean = true;
    globalFilter = '';
    graphFilter: string;
    myAccounts: any;
    chart: any;
    dataSource: any = [];
    dataSourceWithFilter: any = [];
    dataSourceWithFilterLength = 0;
    dataSourceForLegend: any = [];
    UserId: {};
    roleName: any;
    disabled: boolean;
    assessmentId: any;
    public answer;
    myuseridstring: any;
    isOpenErr = false;
    currentRoleId: any;
    errMessage: any;
    currentUser: any;
    status = [];
    columnsToDisplay: any;
    searchAcc: any;
    multipleUserRoleId: any;
    registerForm: FormGroup;
    statusPercentage = [];
    assessmentName: any;
    searchIn = 0;
    filterValueInput: any;
    currentFilterVal = "";
    eventsArray: Array<any> = [];
    discardAction: boolean = false;

    globalData: any;
    allSBUsArray: action[] = [];
    allBUsArray: action[] = [];
    allMarketUnitsArray: action[] = [];
    SBUID: any;
    BUID: any;
    MUID: any;
    bagelOldEvent: any;
    isDisabledBU: boolean = false;
    filter_subtitle_value = "";
    cancelAsmnt: boolean = false;
    giavisibledownload: boolean = false;
    giavisibleresult: boolean = false;
    isDisabledMU: boolean = false;
    selectedsbu: any;
    selectedbu: any;
    currentSBUspocSBUId: any;
    currentBUspocBUId: any;
    currentSBUspocSBUName: any;
    currentBUspocBUName: any;
    begalChartFilterValue: any;
    cancelAsmntdel: boolean = false;
    isSearchCleared: boolean = false;
    globalAssessmentId: any;
    globalAssessmentName: any;

    globalAssessmentTemplateName: any;
    
    globalProgramName: any;
    globalEngangementType: any;
    globalEffectiveDate: any;
    globalSbuName: any;
    globalBuName: any;
    gloablMuName: any;
    globalAccountName: any;
    globalSMEName: any;
    globalAccountSpocName: any;
    globalStatusId: any;
    globalElem: any;
    radioFlag: any;
    pageOneData: any; 
    selectedRow: any;
    selectedRowIndex = -1;

    checkFunctionCount = 0;

    edit_isVisible: boolean = true;
    cancel_isVisible: boolean = true;
    dwnrepot_isVisible: boolean = true;
    resutl_isVisible: boolean = true;
    datafrombackend: any;


    constructor(
        private sbulist: ApiCommonService,
        private bulist: ApiCommonService,
        private marketunits: ApiCommonService,
        private formBuilder: FormBuilder,

        private route: ActivatedRoute,
        private router: Router,
        private assessmentlist: ApiCommonService, private dialog: MatDialog, private getUserStatusService: ApiCommonService, private authenticationService: AuthenticationService,
        private notification: NotificationService,
        private ExportService: ExportService
    ) {
        this.currentUser = this.authenticationService.currentUserValue;

        this.myuseridstring = parseFloat(this.currentUser.returnValue.userId.toString());
        this.currentRoleId = localStorage.getItem('currentRoleId');

        this.UserId = {
            userId: "" + this.myuseridstring,
            currentroleid: "" + this.currentRoleId
        }

    }



    ngOnInit(): void {
        this.ExportService.changeMessage(this.UserId)
        this.isDisabledReset = true;
        this.isDisabledBU = true;
        this.isDisabledMU = true;
        let ngthis = this;
        this.getAssessmentList();

        ngthis.updateLegend();

        //Dropdown section 
        this.registerForm = this.formBuilder.group({
            title: ['', Validators.required],
            title2: ['', Validators.required],
            title3: ['', Validators.required]
        });

        this.sbulist.getRequest(environment.serverUrl + '/sbus', '').subscribe(
            (response => {
                if (response.success === true) {
                    response.returnValue.map(x => {
                        let y: action = { value: x.sbuId, viewValue: x.sbuName };
                        this.allSBUsArray.push(y);
                    })
                } else {
                    //console.log("Error in SBUs fetching :", response.message)
                }
            }), error => {
                if (!error.error.errorDetails) {
                    this.errMessage = error.error.message;
                } else {
                    this.errMessage = error.error.errorDetails[0].message;
                }
                this.notification.warn(this.errMessage);
            });

    }


    @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
    @ViewChild(MatSort, { static: false }) sort: MatSort;
    getAssessmentList() {
        let localAssessmentObj: assessmentTable[] = [];
        let self = this;
        if (this.currentRoleId !== "10" && this.currentRoleId !== "9" && this.currentRoleId !== "8") {


            this.assessmentlist.insertRequest(`${environment.serverUrl}/assessments/userlanding`, '', this.UserId)
                .subscribe(response => {
                    response.returnValue.assessments.map((data) => {
                        this.assessmentId = data.assessmentDetail.assessmentId;
                        localAssessmentObj.push({
                            srNo: data.assessmentDetail.assessmentId,
                            assessmentName: data.assessmentDetail.assessmentName,
                            templateName: data.templateDetail.templateName,
                            assessmentType: data.templateDetail.assessmentType.assessmentTypeName,
                            engagementType: data.templateDetail.assessmentType.engagement,
                            engagementName: (data.accountDetail.towerName !== undefined) ? data.accountDetail.towerName : "",
                            programName: data.accountDetail.programName,
                            status: data.assessmentDetail.assessmentStatus.name,
                            statusId: data.assessmentDetail.assessmentStatus.statusId,
                            smeName: (data.smeuser === null) ? "" : data.smeuser.longName,
                            accountId: (data.accountDetail === null) ? "" : data.accountDetail.accountId,
                            accountName: (data.accountDetail === null) ? "" : data.accountDetail.accountName,
                            accountSpocName: (data.accountspoc === null) ? "" : data.accountspoc.longName,
                            projectMemberNames: data.teamMembers.map(i => i.longName).join(","),
                            sbu: (data.accountDetail.sbu === undefined) ? "" : data.accountDetail.sbu.sbuName,
                            bu: (data.accountDetail.bu === undefined) ? "" : data.accountDetail.bu.buName,
                            mu: (data.accountDetail.marketUnit === undefined) ? "" : data.accountDetail.marketUnit.name,
                            startDate: data.assessmentDetail.startDate
                        });
                    });
                    this.dataSource = new MatTableDataSource<assessmentTable>(localAssessmentObj);
                    setTimeout(() => this.dataSource.paginator = this.paginator);
                    this.dataSource.sort = this.sort;

                    this.dataSource.filterPredicate = function (data, filter: string): boolean {
                        if (self.searchIn == 1) {
                            return data.statusId.toString() === self.globalFilter && (data.assessmentName.toString().toLowerCase().includes(filter) || data.smeName.toString().toLowerCase().includes(filter) || data.assessmentType.toString().toLowerCase().includes(filter) || data.accountSpocName.toString().toLowerCase().includes(filter) || data.projectMemberNames.toString().toLowerCase().includes(filter) || data.templateName.toString().toLowerCase().includes(filter) || data.engagementType.toString().toLowerCase().includes(filter) || data.accountName.toString().toLowerCase().includes(filter) || data.engagementName.toString().toLowerCase().includes(filter) || data.programName.toString().toLowerCase().includes(filter)) && data.mu.toString().includes(self.currentMU) && data.bu.toString().includes(self.currentBU) && data.sbu.toString().includes(self.currentSBU);
                        } else {
                            return data.statusId.toString() === filter;
                        }
                    };

                    if (localStorage.getItem('returnToAssessment') === "true") {
                        this.applyFilter(Number(localStorage.getItem('appliedBegalFilter')));
                        localStorage.setItem('returnToAssessment', "false");
                    } else if (localStorage.getItem('isClickedBegal') === "true") {
                        this.applyFilter(Number(localStorage.getItem('appliedBegalFilter')));
                        // localStorage.setItem('isClickedBegal',"false");
                    } else {
                        if (this.currentRoleId === "1") {
                            this.applyFilter(2);
                        } else {
                            this.applyFilter(0);
                        }

                    }
                },
                    (error) => {
                        //console.log(err)
                        if (!error.error.errorDetails) {
                            this.errMessage = error.error.message;
                        } else {
                            this.errMessage = error.error.errorDetails[0].message;
                        }
                        this.notification.warn(this.errMessage);
                    });


        } else {




            this.assessmentlist.insertRequest(`${environment.serverUrl}/assessments/userlanding`, '', this.UserId)
                .subscribe(response => {

                    response.returnValue.assessments.map((data) => {
                        this.assessmentId = data.assessmentDetail.assessmentId;
                        localAssessmentObj.push({
                            srNo: data.assessmentDetail.assessmentId,
                            assessmentName: data.assessmentDetail.assessmentName,
                            templateName: data.templateDetail.templateName,
                            assessmentType: data.templateDetail.assessmentType.assessmentTypeName,
                            engagementType: data.templateDetail.assessmentType.engagement,
                            engagementName: (data.accountDetail.towerName !== undefined) ? data.accountDetail.towerName : "",
                            programName: data.accountDetail.programName,
                            status: data.assessmentDetail.assessmentStatus.name,
                            statusId: data.assessmentDetail.assessmentStatus.statusId,
                            smeName: (data.smeuser === null) ? "" : data.smeuser.longName,
                            accountId: (data.accountDetail === null) ? "" : data.accountDetail.accountId,
                            accountName: (data.accountDetail === null) ? "" : data.accountDetail.accountName,
                            accountSpocName: (data.accountspoc === null) ? "" : data.accountspoc.longName,
                            projectMemberNames: data.teamMembers.map(i => i.longName).join(","),
                            sbu: (data.accountDetail.sbu === undefined) ? "" : data.accountDetail.sbu.sbuName,
                            bu: (data.accountDetail.bu === undefined) ? "" : data.accountDetail.bu.buName,
                            mu: (data.accountDetail.marketUnit === undefined) ? "" : data.accountDetail.marketUnit.name,
                            startDate: data.assessmentDetail.startDate
                        });
                    });

                    this.dataSource = new MatTableDataSource<assessmentTable>(localAssessmentObj);

                    this.globalData = localAssessmentObj;
                    setTimeout(() => this.dataSource.paginator = this.paginator);
                    this.dataSource.sort = this.sort;


                    this.fetch_currentSBUspocSBUId = response.returnValue.assessments[0].accountDetail.sbu.sbuId;
                    this.fetch_currentBUspocBUId = response.returnValue.assessments[0].accountDetail.bu.buId;

                    if (this.currentRoleId === "8") {
                        this.changeSBUs(parseInt(this.fetch_currentSBUspocSBUId));
                    } else if (this.currentRoleId === "9") {
                        this.changeSBUs(parseInt(this.fetch_currentSBUspocSBUId));
                        this.changeBUs(parseInt(this.fetch_currentBUspocBUId));
                    } else {
                        this.filter_subtitle_value = "Global Level";
                    }


                    this.dataSource.filterPredicate = function (data, filter: string): boolean {
                        if (self.searchIn === 1) {
                            return data.statusId.toString() === self.globalFilter && (data.assessmentName.toString().toLowerCase().includes(filter) || data.smeName.toString().toLowerCase().includes(filter) || data.assessmentType.toString().toLowerCase().includes(filter) || data.accountSpocName.toString().toLowerCase().includes(filter) || data.projectMemberNames.toString().toLowerCase().includes(filter) || data.templateName.toString().toLowerCase().includes(filter) || data.engagementType.toString().toLowerCase().includes(filter) || data.accountName.toString().toLowerCase().includes(filter) || data.engagementName.toString().toLowerCase().includes(filter) || data.programName.toString().toLowerCase().includes(filter)) && data.mu.toString().includes(self.currentMU) && data.bu.toString().includes(self.currentBU) && data.sbu.toString().includes(self.currentSBU);
                        } else if (self.searchIn === 2) {
                            return data.sbu.toString() === filter && data.statusId.toString() === self.globalFilter;
                        } else if (self.searchIn === 3) {
                            if (self.currentMU.length !== 0) {
                                return data.statusId.toString() === self.globalFilter && data.bu.toString() === filter && data.sbu.toString() === self.currentSBU && data.mu.toString() === self.currentMU;
                            } else {
                                return data.statusId.toString() === self.globalFilter && data.bu.toString() === filter && data.sbu.toString() === self.currentSBU;
                            }
                        } else if (self.searchIn === 4) {
                            return data.statusId.toString() === self.globalFilter && data.mu.toString() === filter && data.bu.toString() === self.currentBU && data.sbu.toString() === self.currentSBU;
                        } else {
                            if (self.currentSBU.length !== 0 && self.currentBU.length === 0 && self.currentMU.length === 0) {
                                return data.statusId.toString() === self.globalFilter && data.sbu.toString() === self.currentSBU;
                            } else if (self.currentSBU.length !== 0 && self.currentBU.length !== 0 && self.currentMU.length === 0) {
                                return data.statusId.toString() === self.globalFilter && data.sbu.toString() === self.currentSBU && data.bu.toString() === self.currentBU;
                            } else if (self.currentSBU.length !== 0 && self.currentBU.length !== 0 && self.currentMU.length !== 0) {
                                return data.statusId.toString() === self.globalFilter && data.sbu.toString() === self.currentSBU && data.bu.toString() === self.currentBU && data.mu.toString() === self.currentMU;
                            } else if (self.currentSBU.length !== 0 && self.currentBU.length === 0 && self.currentMU.length !== 0) {
                                return data.statusId.toString() === self.globalFilter && data.sbu.toString() === self.currentSBU && data.mu.toString() === self.currentMU;
                            } else {
                                return data.statusId.toString() === filter;
                            }
                        }
                    };

                    if (localStorage.getItem('returnToAssessment') === "true") {
                        this.applyFilter(Number(localStorage.getItem('appliedBegalFilter')));
                        localStorage.setItem('returnToAssessment', "false");
                    } else if (localStorage.getItem('isClickedBegal') === "true") {
                        this.applyFilter(Number(localStorage.getItem('appliedBegalFilter')));
                        // localStorage.setItem('isClickedBegal',"false");
                    } else {
                        if (this.currentRoleId === "1") {
                            this.applyFilter(2);
                        } else if (this.currentRoleId === "10" || this.currentRoleId === "9" || this.currentRoleId === "8") {
                            this.applyFilter(4)
                        } else {
                            this.applyFilter(0);
                        }

                    }

                }, (error) => {
                    //console.log(err)
                    if (!error.error.errorDetails) {
                        this.errMessage = error.error.message;
                    } else {
                        this.errMessage = error.error.errorDetails[0].message;
                    }
                    this.notification.warn(this.errMessage);
                });



        }

        if (this.currentRoleId === "1") { //sme
            this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];

        } else if (this.currentRoleId === "10" || this.currentRoleId === "9" || this.currentRoleId === "8") { //gia or sbu/bu spoc
            this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

        } else if (this.currentRoleId === "2" || this.currentRoleId === "3") {
            this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];

        } else {
            this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];
        }

    }

    globalFilterCount() {


        //console.log("GLOBAL")
        //console.log(this.globalData);


        //console.log(this.currentSBU.length + " = " + this.currentBU.length + " = " + this.currentMU.length)
        let count = this.globalData.length;

        if (this.currentSBU.length !== 0 || this.currentBU.length !== 0 || this.currentMU.length !== 0) {
            count = 0;
            if (this.globalData !== undefined) {
                this.globalData.map((x) => {
                    if (this.currentSBU.length !== 0 && this.currentBU.length === 0 && this.currentMU.length === 0) {
                        //console.log("1");
                        if (x.sbu === this.currentSBU) {
                            count += 1;
                        }
                    } else if (this.currentSBU.length !== 0 && this.currentBU.length !== 0 && this.currentMU.length === 0) {
                        //console.log("2")
                        if (x.sbu === this.currentSBU && x.bu === this.currentBU) {
                            count += 1;
                        }
                    } else if (this.currentSBU.length !== 0 && this.currentBU.length !== 0 && this.currentMU.length !== 0) {
                        //console.log("3")
                        if (x.sbu === this.currentSBU && x.bu === this.currentBU && x.mu === this.currentMU) {
                            count += 1;
                        }
                    } else if (this.currentSBU.length !== 0 && this.currentBU.length === 0 && this.currentMU.length !== 0) {
                        //console.log("4")
                        if (x.sbu === this.currentSBU && x.bu !== this.currentBU && x.mu === this.currentMU) {
                            count += 1;
                        }
                    }
                });

            }
        }


        return count;

    }

    clearAccSearch() {
        let self = this;
        // this.isSearchCleared = true;
        this.searchAcc = '';
        // this.dataSource.filter = '';
        // this.dataSourceWithFilter = this.dataSource;
        // this.dataSourceWithFilter.filteredData = this.dataSource.filteredData.filter(x =>
        //   x.statusId === parseInt(self.globalFilter)
        // );
        // this.dataSourceWithFilter._data._value = this.dataSource._data._value.filter(x =>
        //   x.statusId === parseInt(self.globalFilter)
        // );
        // this.dataSourceWithFilter._renderData._value = this.dataSource.filteredData.filter(x =>
        //   x.statusId === parseInt(self.globalFilter)
        // );
        // setTimeout(() => this.dataSourceWithFilter.paginator = this.paginator);
        // this.dataSourceWithFilterLength = this.dataSourceWithFilter.filteredData.length;

        let currentFilter = Number(self.globalFilter) - 1;
        //alert(currentFilter);
        this.applyFilter(currentFilter);
    }


    accountFilter(event: any) {
        this.searchIn = 1;
        this.filterValueInput = (event.target as HTMLInputElement).value;

        if (this.filterValueInput.length === 0) {
            if (event.keyCode === 8) {
                //On backspace release, skip
                // console.log("1st fire");
                this.clearAccSearch();
            } else {
                this.clearAccSearch();
            }
        } else {
            setTimeout(function () {
                const el = document.querySelector('.mat-input-element') as HTMLInputElement;
                el.focus();
            }, 200);
            this.dataSourceWithFilterLength = 0;
            this.dataSourceWithFilter = [];
            this.dataSource.filter = this.filterValueInput.trim().toLowerCase();
            setTimeout(() => this.dataSource.paginator = this.paginator);
        }
    }

    applyFilter(filterValue: any): void {

        if (sessionStorage.getItem("cancelTrigger") === "true") {
            this.notification.success('The Assessment has been cancelled successfully');
            let appliedFilter = Number(sessionStorage.getItem("appliedFilter")) - 1;
            this.currentSBU = sessionStorage.getItem("appliedSBU");
            this.currentBU = sessionStorage.getItem("appliedBU");
            this.currentMU = sessionStorage.getItem("appliedMU");

            let appliedSBUID = sessionStorage.getItem("appliedSBUID") === "undefined" ? "" : sessionStorage.getItem("appliedSBUID");
            let appliedBUID = sessionStorage.getItem("appliedBUID") === "undefined" ? "" : sessionStorage.getItem("appliedBUID");
            let appliedMUID = sessionStorage.getItem("appliedMUID") === "undefined" ? "" : sessionStorage.getItem("appliedMUID");

            this.loadDropdowns(appliedSBUID, appliedBUID, appliedMUID)
            this.filterSetter(appliedFilter);
            sessionStorage.clear();

        } else {
            this.filterSetter(filterValue);
        }

    }

    loadDropdowns(appliedSBUID, appliedBUID, appliedMUID) {
        this.SBUID = Number(appliedSBUID);
        this.BUID = Number(appliedBUID);
        this.MUID = Number(appliedMUID);
        this.registerForm.controls['title'].setValue(Number(appliedSBUID));
        this.bulist.getRequest(environment.serverUrl + '/sbus', '').subscribe((response => {
            if (response.success === true) {
                response.returnValue.map(p => {
                    if (appliedSBUID !== "" && appliedSBUID !== "0") {
                        if (p.sbuId === Number(appliedSBUID)) {
                            this.currentSBU = p.sbuName;
                            p.bus.map(r => {
                                if (appliedBUID !== "" && appliedBUID !== "0") {
                                    if (r.buId === Number(appliedBUID)) {
                                        this.currentBU = r.buName;
                                        this.filter_subtitle_value = "BU - " + this.currentBU;
                                    }
                                }
                                let q: action = { value: r.buId, viewValue: r.buName };
                                this.allBUsArray.push(q);
                            });
                            this.isDisabledBU = false;
                            this.isDisabledReset = false;
                            this.registerForm.controls['title2'].setValue(Number(appliedBUID));
                            if (this.currentMU === "") {
                                if (this.currentBU === "") {
                                    this.filter_subtitle_value = "SBU - " + this.currentSBU;
                                }
                            } else {
                                this.filter_subtitle_value = "MU - " + this.currentMU;
                            }
                            this.answer = this.globalFilterCount();
                        }
                    }

                    if (appliedMUID !== "" && appliedMUID !== "0") {
                        this.marketunits.getRequest(environment.serverUrl + '/marketunits', '').subscribe((response => {
                            if (response.success === true) {
                                response.returnValue.map(m => {
                                    let n: action = { value: m.marketUnitId, viewValue: m.name };
                                    this.allMarketUnitsArray.push(n);
                                    if (m.marketUnitId === appliedMUID) {
                                        this.currentMU = m.name;

                                    }
                                })
                                this.isDisabledMU = false;
                                this.isDisabledReset = false;
                                this.registerForm.controls['title3'].setValue(Number(appliedMUID));
                            } else {
                                //console.log("Error in Market units fetching :", response.message)
                            }
                        }));
                    }

                })
            } else {
                //console.log("Error in SBUs fetching :", response.message)
            }
        }), error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });
    }


    filterSetter(filterValue: any) {
        this.searchIn = 0;
        filterValue += 1;
        filterValue = filterValue.toString();



        this.globalFilter = filterValue.toString();



        this.dataSource.filter = filterValue;
        if (this.filterValueInput === undefined) {
            this.dataSource.filter = filterValue;
            this.radioFlag = (this.dataSource.filteredData[0] !== undefined) ? this.dataSource.filteredData[0].srNo : "";
            // var target = <HTMLElement>document.querySelector(".radio-ticks");

            setTimeout(function () {
                let yourElem = (<HTMLScriptElement[]><any>document.querySelectorAll(".radio-ticks"));
                //  console.log(yourElem);
                if (yourElem && yourElem.length) {
                    yourElem[0].click();
                }
            }, 10);





        } else {
            this.searchAcc = '';
            // if(this.isSearchCleared === true){ //open the door
            //   //regain all data by default filter options
            //   this.getAssessmentList();
            //   this.dataSource.filter = filterValue;
            //   this.isSearchCleared = false; //close the door
            // }else{
            this.dataSource.filter = filterValue;
            this.radioFlag = (this.dataSource.filteredData[0] !== undefined) ? this.dataSource.filteredData[0].srNo : "";

            setTimeout(function () {
                let yourElem = (<HTMLScriptElement[]><any>document.querySelectorAll(".radio-ticks"));
                //  console.log(yourElem);
                if (yourElem && yourElem.length) {
                    yourElem[0].click();
                }
            }, 10);


            // }

        }

        if (this.currentRoleId === "10" || this.currentRoleId === "9" || this.currentRoleId === "8") {
            //gia or sbu/bu spoc


            if (this.globalFilter === '1') {
                this.edit_isVisible = true;
                this.cancel_isVisible = true;
                this.dwnrepot_isVisible = false;
                this.resutl_isVisible = false;
            } else if (this.globalFilter === '2') {
                this.edit_isVisible = true;
                this.cancel_isVisible = true;
                this.dwnrepot_isVisible = false;
                this.resutl_isVisible = false;
            } else if (this.globalFilter === '3') {
                this.edit_isVisible = true;
                this.cancel_isVisible = true;
                this.dwnrepot_isVisible = true;
                this.resutl_isVisible = true;
            } else if (this.globalFilter === '4') {
                this.edit_isVisible = true;
                this.cancel_isVisible = false;
                this.dwnrepot_isVisible = true;
                this.resutl_isVisible = true;
            } else if (this.globalFilter === '5') {
                this.edit_isVisible = true;
                this.cancel_isVisible = false;
                this.dwnrepot_isVisible = true;
                this.resutl_isVisible = true;
            } else if (this.globalFilter === '6') {
                this.edit_isVisible = false;
                this.cancel_isVisible = false;
                this.dwnrepot_isVisible = false;
                this.resutl_isVisible = false;
            }

            if (this.globalFilter === '1') {
                this.cancelAsmnt = false;
                this.cancelAsmntdel = false;
                this.giavisibledownload = true;
                this.giavisibleresult = true;
                this.disabled = true;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            } else if (this.globalFilter === '2') {
                this.cancelAsmnt = false;
                this.cancelAsmntdel = false;
                this.giavisibledownload = true;
                this.giavisibleresult = true;
                this.disabled = true;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            } else if (this.globalFilter === '3') {
                this.cancelAsmnt = false;
                this.cancelAsmntdel = false;
                this.giavisibledownload = false;
                this.giavisibleresult = false;
                this.disabled = false;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            } else if (this.globalFilter === '4') {
                this.cancelAsmnt = false;
                this.cancelAsmntdel = true;
                this.giavisibledownload = false;
                this.giavisibleresult = false;
                this.disabled = false;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            } else if (this.globalFilter === '5') {
                this.cancelAsmnt = false;
                this.cancelAsmntdel = true;
                this.giavisibledownload = false;
                this.giavisibleresult = false;
                this.disabled = false;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            } else if (this.globalFilter === '6') {
                this.cancelAsmnt = true;
                this.cancelAsmntdel = true;
                this.giavisibledownload = true;
                this.giavisibleresult = true;
                this.disabled = true;
                this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'SBU', 'BU', 'Market Unit', 'Start Date'];

            }

        } else { //sme and automation spoc/project member

            if (this.currentRoleId === "1") { //sme 
                if (this.globalFilter === '6' || this.globalFilter === "1" || this.globalFilter === '2') {
                    this.disabled = true;
                } else {
                    this.disabled = false;
                }


                if (this.globalFilter === '1') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                } else if (this.globalFilter === '2') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                } else if (this.globalFilter === '3') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '4') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '5') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '6') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                }
            } else if (this.currentRoleId === "2" || this.currentRoleId === "3") { //automation spoc/project member - 2,3
                if (this.globalFilter === '6') {
                    this.disabled = true;
                } else {
                    this.disabled = false;
                }


                if (this.globalFilter === '1') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                } else if (this.globalFilter === '2') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                } else if (this.globalFilter === '3') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '4') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '5') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = true;
                    this.resutl_isVisible = true;
                } else if (this.globalFilter === '6') {
                    this.edit_isVisible = false;
                    this.cancel_isVisible = false;
                    this.dwnrepot_isVisible = false;
                    this.resutl_isVisible = false;
                }

            }

            if (this.globalFilter !== '1' && this.globalFilter !== '2' && this.globalFilter !== '6') {
                if (this.currentRoleId === "1" || this.currentRoleId === "2" || this.currentRoleId === "3") {
                    this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];
                }

                else {
                    this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];
                }
            } else {
                if (this.currentRoleId === "1" || this.currentRoleId === "2" || this.currentRoleId === "3") {
                    this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];
                } else {
                    this.columnsToDisplay = ['radioBtn', 'Assessment ID', 'Assessment Name', 'Template Name', 'Assessment Type', 'Engagement type', 'Account name', 'Engagement name', 'Program name', 'SME name', 'Account Spoc Name', 'Project Member Name', 'Start Date'];

                }
            }
        }
    }


    updateLegend() {
        let status_userlanding = 0;
        let status_charts = 0;
        let localAssessmentObj: assessmentTable[] = [];
        let self = this;
        this.assessmentlist.insertRequest(`${environment.serverUrl}/assessments/userlanding`, '', this.UserId)
            .subscribe(response => {
                status_userlanding = 1;
                let stat_1 = 0;
                let stat_2 = 0;
                let stat_3 = 0;
                let stat_4 = 0;
                let stat_5 = 0;
                let stat_6 = 0;
                response.returnValue.assessments.map((data) => {
                    this.assessmentId = data.assessmentDetail.assessmentId;
                    localAssessmentObj.push({
                        srNo: data.assessmentDetail.assessmentId,
                        assessmentName: data.assessmentDetail.assessmentName,
                        templateName: data.templateDetail.templateName,
                        assessmentType: data.templateDetail.assessmentType.assessmentTypeName,
                        engagementType: data.templateDetail.assessmentType.engagement,
                        engagementName: data.accountDetail.towerName,
                        programName: data.accountDetail.programName,
                        status: data.assessmentDetail.assessmentStatus.name,
                        statusId: data.assessmentDetail.assessmentStatus.statusId,
                        smeName: (data.smeuser === null) ? "" : data.smeuser.longName,
                        accountId: (data.accountDetail === null) ? "" : data.accountDetail.accountId,
                        accountName: (data.accountDetail === null) ? "" : data.accountDetail.accountName,
                        accountSpocName: (data.accountspoc === null) ? "" : data.accountspoc.longName,
                        projectMemberNames: data.teamMembers.map(i => i.longName).join(","),
                        sbu: (data.accountDetail.sbu === undefined) ? "" : data.accountDetail.sbu.sbuName,
                        bu: (data.accountDetail.bu === undefined) ? "" : data.accountDetail.bu.buName,
                        mu: (data.accountDetail.marketUnit === undefined) ? "" : data.accountDetail.marketUnit.name,
                        startDate: data.assessmentDetail.startDate
                    });
                });
                if (self.currentSBU.length !== 0 && self.currentBU.length === 0 && self.currentMU.length === 0) {
                    localAssessmentObj.map((x) => {
                        if (x.statusId.toString() === "1" && x.sbu === self.currentSBU) {
                            stat_1 += 1;
                        } else if (x.statusId.toString() === "2" && x.sbu === self.currentSBU) {
                            stat_2 += 1;
                        } else if (x.statusId.toString() === "3" && x.sbu === self.currentSBU) {
                            stat_3 += 1;
                        } else if (x.statusId.toString() === "4" && x.sbu === self.currentSBU) {
                            stat_4 += 1;
                        } else if (x.statusId.toString() === "5" && x.sbu === self.currentSBU) {
                            stat_5 += 1;
                        } else if (x.statusId.toString() === "6" && x.sbu === self.currentSBU) {
                            stat_6 += 1;
                        }
                    });
                } else if (self.currentSBU.length !== 0 && self.currentBU.length !== 0 && self.currentMU.length === 0) {
                    localAssessmentObj.map((x) => {
                        if (x.statusId.toString() === "1" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_1 += 1;
                        } else if (x.statusId.toString() === "2" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_2 += 1;
                        } else if (x.statusId.toString() === "3" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_3 += 1;
                        } else if (x.statusId.toString() === "4" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_4 += 1;
                        } else if (x.statusId.toString() === "5" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_5 += 1;
                        } else if (x.statusId.toString() === "6" && x.sbu === self.currentSBU && x.bu === self.currentBU) {
                            stat_6 += 1;
                        }
                    });
                } else if (self.currentSBU.length !== 0 && self.currentBU.length !== 0 && self.currentMU.length !== 0) {
                    localAssessmentObj.map((x) => {
                        if (x.statusId.toString() === "1" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_1 += 1;
                        } else if (x.statusId.toString() === "2" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_2 += 1;
                        } else if (x.statusId.toString() === "3" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_3 += 1;
                        } else if (x.statusId.toString() === "4" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_4 += 1;
                        } else if (x.statusId.toString() === "5" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_5 += 1;
                        } else if (x.statusId.toString() === "6" && x.sbu === self.currentSBU && x.bu === self.currentBU && x.mu === self.currentMU) {
                            stat_6 += 1;
                        }
                    });
                } else if (self.currentSBU.length !== 0 && self.currentBU.length === 0 && self.currentMU.length !== 0) {
                    localAssessmentObj.map((x) => {
                        if (x.statusId.toString() === "1" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_1 += 1;
                        } else if (x.statusId.toString() === "2" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_2 += 1;
                        } else if (x.statusId.toString() === "3" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_3 += 1;
                        } else if (x.statusId.toString() === "4" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_4 += 1;
                        } else if (x.statusId.toString() === "5" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_5 += 1;
                        } else if (x.statusId.toString() === "6" && x.sbu === self.currentSBU && x.mu === self.currentMU) {
                            stat_6 += 1;
                        }
                    });
                } else {
                    //on page load
                    localAssessmentObj.map((x) => {
                        if (x.statusId.toString() === "1") {
                            stat_1 += 1;
                        } else if (x.statusId.toString() === "2") {
                            stat_2 += 1;
                        } else if (x.statusId.toString() === "3") {
                            stat_3 += 1;
                        } else if (x.statusId.toString() === "4") {
                            stat_4 += 1;
                        } else if (x.statusId.toString() === "5") {
                            stat_5 += 1;
                        } else if (x.statusId.toString() === "6") {
                            stat_6 += 1;
                        }
                    });
                }



                self.dataSourceForLegend = [stat_1, stat_2, stat_3, stat_4, stat_5, stat_6];




                this.getUserStatusService.insertRequest(`${environment.serverUrl}/assessments/charts`, 'POST', this.UserId)
                    .subscribe(result => {

                        status_charts = 1;
                        this.statusPercentage = [];
                        const intValue = self.dataSourceForLegend.map(Number);
                        function add(acc, value) {
                            return acc + value;
                        }
                        this.answer = intValue.reduce(add);

                        // if(this.chart!=null){
                        //   this.chart.destroy(); 
                        // }

                        this.chart = Highcharts.chart(this.container.nativeElement, {

                            chart: {

                                // events: {
                                //   load: function (e){
                                //     this.series[0].data[0].slice();
                                //     return false;
                                //   }
                                // },


                                type: "pie",
                                backgroundColor: null,
                                options3d: {

                                    enabled: true,

                                    alpha: 45,

                                    beta: 0,

                                },

                            },

                            title: {

                                text: null,

                            },

                            credits: {

                                enabled: false,

                            },

                            tooltip: { enabled: false },
                            // tooltip: { backgroundColor: '#FFF',
                            // borderColor: 'black',
                            // borderRadius: 10,
                            // borderWidth: 1 },

                            plotOptions: {

                                series: {

                                    animation: false,

                                },

                                pie: {

                                    cursor: "pointer",

                                    allowPointSelect: true,

                                    innerSize: 150,

                                    depth: 45,

                                    slicedOffset: 3,

                                    dataLabels: {

                                        enabled: false,

                                    },

                                    states: {

                                        inactive: {

                                            opacity: 1,

                                        },

                                        select: {

                                            borderWidth: 0,

                                            // borderColor: "red",

                                        },

                                    },

                                },

                            },

                            series: [

                                {

                                    showInLegend: false,

                                    name: "",

                                    data: [

                                        {

                                            name: "Intiated",

                                            y: this.dataSourceForLegend[0],

                                            color: "#860864",


                                            // sliced: true
                                            //  selected: true,

                                        },

                                        {

                                            name: "In-progress-Self Assessment",

                                            y: this.dataSourceForLegend[1],

                                            color: "#4701A7",

                                        },

                                        {

                                            name: "In-Progress-SME review",

                                            y: this.dataSourceForLegend[2],

                                            color: "#12B3DB",

                                        },

                                        {

                                            name: "Baselined",

                                            y: this.dataSourceForLegend[3],

                                            color: "#00C37B",

                                        },

                                        {

                                            name: "Completed",

                                            y: this.dataSourceForLegend[4],

                                            color: "#95E616",

                                        },

                                        {

                                            name: "Cancelled",

                                            y: this.dataSourceForLegend[5],

                                            color: "#FF7E83",

                                        },

                                    ],

                                    type: "pie",

                                    innerSize: "60%",

                                    point: {

                                        events: {


                                            click: function (event) {

                                                // this.update({ borderColor: "blue" });

                                                if (this.name == "Intiated") {

                                                    let filterIndex = 0;

                                                    self.applyFilter(filterIndex);

                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                } else if (this.name == "In-progress-Self Assessment") {

                                                    let filterIndex = 1;

                                                    self.applyFilter(filterIndex);
                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                } else if (this.name == "In-Progress-SME review") {

                                                    let filterIndex = 2;

                                                    self.applyFilter(filterIndex);
                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                } else if (this.name == "Baselined") {

                                                    let filterIndex = 3;

                                                    self.applyFilter(filterIndex);
                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                } else if (this.name == "Completed") {

                                                    let filterIndex = 4;

                                                    self.applyFilter(filterIndex);
                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                } else if (this.name == "Cancelled") {

                                                    let filterIndex = 5;

                                                    self.applyFilter(filterIndex);
                                                    localStorage.setItem('isClickedBegal', "" + true);
                                                    localStorage.setItem('appliedBegalFilter', "" + filterIndex);

                                                }

                                            },

                                        },

                                    },

                                },

                            ],

                        });


                    },
                        error => {

                            if (!error.error.errorDetails) {
                                this.errMessage = error.error.message;
                            } else {
                                this.errMessage = error.error.errorDetails[0].message;
                            }
                            this.notification.warn(this.errMessage);
                        });



            }, error => {
                if (!error.error.errorDetails) {
                    this.errMessage = error.error.message;
                } else {
                    this.errMessage = error.error.errorDetails[0].message;
                }
                this.notification.warn(this.errMessage);
            });

        self.timer = setInterval(function () {
            if (status_userlanding === 1 && status_charts === 1) {
                self.doSpin = false;
                status_userlanding = 0;
                status_charts = 0;
                clearTimeout(self.timer);
            }
        }, 1);
    }

    changeSBUs(value) {
        this.searchAcc = '';
        this.searchIn = 2;
        this.SBUID = value;

        this.doSpin = true;

        this.allBUsArray = [];
        this.bulist.getRequest(environment.serverUrl + '/sbus', '').subscribe((response => {
            if (response.success === true) {

                response.returnValue.map(p => {

                    if (p.sbuId === this.SBUID) {
                        this.currentSBU = p.sbuName;

                        if (this.currentRoleId !== "9") {
                            this.filter_subtitle_value = "SBU - " + this.currentSBU;
                        }
                        this.updateLegend();
                        //console.log("DATA")
                        //console.log(this.dataSource);
                        this.dataSource.filter = this.currentSBU;


                        //console.log("****");
                        //console.log(this.dataSource);
                        p.bus.map(r => {
                            let q: action = { value: r.buId, viewValue: r.buName };
                            //console.log(q)
                            this.allBUsArray.push(q);
                            if (this.currentRoleId !== "8") {
                                this.isDisabledReset = false;
                            }

                        })
                        this.isDisabledBU = false;




                    }
                })


                this.currentBU = "";


                //reset MU
                this.currentMU = "";
                this.registerForm.controls['title3'].setValue(undefined);
                this.isDisabledMU = true;
                this.allMarketUnitsArray = [];

                (this.currentRoleId === "9") ? this.isDisabledMU = false : "";


                this.answer = this.globalFilterCount();
            } else {
                //console.log("Error in SBUs fetching :", response.message)
            }
        }), error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });
    }


    changeBUs(value) {
        this.searchAcc = '';
        this.searchIn = 3;
        this.BUID = value;
        this.isDisabledMU = false;




        this.doSpin = true;
        this.bulist.getRequest(environment.serverUrl + '/sbus', '').subscribe((response => {
            if (response.success === true) {
                response.returnValue.map(p => {
                    if (p.sbuId === this.SBUID) {
                        p.bus.map(r => {

                            if (r.buId === this.BUID) {
                                this.currentBU = r.buName;
                                this.filter_subtitle_value = "BU - " + this.currentBU;
                                this.updateLegend();
                                this.dataSource.filter = this.currentBU;

                            }

                        })
                    }
                })
                if (this.currentRoleId === "8") {
                    this.isDisabledReset = false;
                }

                if (this.currentRoleId === "9") {
                    this.isDisabledReset = true;
                }

                if (this.resetTrigger === true) {
                    if (this.currentRoleId === "9") {
                        this.isDisabledReset = true;
                    }
                    this.resetTrigger = false;
                }

                this.answer = this.globalFilterCount();
            } else {
                //console.log("Error in SBUs fetching :", response.message)
            }

            this.marketunits.getRequest(environment.serverUrl + '/marketunits', '').subscribe((response => {
                if (response.success === true) {
                    response.returnValue.map(m => {
                        let n: action = { value: m.marketUnitId, viewValue: m.name };
                        this.allMarketUnitsArray.push(n);
                    })

                } else {
                    //console.log("Error in Market units fetching :", response.message)
                }
            }));
        }), error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });


    }
    changeMUs(value) {
        this.searchAcc = '';
        this.searchIn = 4;
        this.MUID = value;

        this.doSpin = true;
        this.marketunits.getRequest(environment.serverUrl + '/marketunits', '').subscribe((response => {
            if (response.success === true) {
                response.returnValue.map(m => {
                    if (m.marketUnitId === this.MUID) {
                        this.currentMU = m.name;
                        this.filter_subtitle_value = "MU - " + this.currentMU;
                        this.updateLegend();
                        this.dataSource.filter = this.currentMU;
                    }


                })
                if (this.currentRoleId === "8") {
                    this.isDisabledReset = false;
                }
                if (this.currentRoleId === "9") {
                    this.isDisabledReset = false;
                }
                this.answer = this.globalFilterCount();
            } else {
                //console.log("Error in Market units fetching :", response.message)
            }
        }), error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });

    }
    resetFilters() {
        this.searchIn = -1;
        this.searchAcc = '';

        this.currentMU = "";
        this.registerForm.controls['title2'].setValue(undefined);
        this.allMarketUnitsArray = [];

        (this.isDisabledReset !== true) ? this.doSpin = true : '';


        if (this.currentRoleId === "8") {

            this.registerForm.controls['title3'].setValue(undefined);
            this.changeSBUs(parseInt(this.fetch_currentSBUspocSBUId));
            this.isDisabledMU = true;
            this.currentBU = "";
            this.isDisabledReset = true;

        } else if (this.currentRoleId === "9") {

            this.filter_subtitle_value = "BU - " + this.currentBU;
            this.changeSBUs(parseInt(this.fetch_currentSBUspocSBUId));
            this.changeBUs(parseInt(this.fetch_currentBUspocBUId));
            this.resetTrigger = true;
            this.isDisabledReset = true;

        } else {

            this.registerForm.controls['title'].setValue(undefined);
            this.filter_subtitle_value = "Global Level";
            this.allBUsArray = [];
            this.isDisabledBU = true;
            this.currentSBU = "";
            this.registerForm.controls['title3'].setValue(undefined);
            this.isDisabledMU = true;
            this.currentBU = "";
            this.isDisabledReset = true;

        }


        this.answer = this.globalFilterCount();
        this.dataSource.filter = this.globalFilter;
        // console.log(this.dataSource)
        this.updateLegend();
    }
    deleteAssessment() {
        let self = this;
        this.assessmentName = this.globalAssessmentName;
        let assessmentId = this.globalAssessmentId;

        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        const dialogRef: MatDialogRef<CancelPopupComponent> = this.dialog.open(CancelPopupComponent, { panelClass: 'cancelModal', data: { id: assessmentId, name: this.assessmentName } });
        dialogRef.afterClosed().subscribe(result => {
            if (result !== undefined) {
                if (result.status === true) {
                    if (result.event === "cancel") {
                        //skip
                    } else if (result.event === "canceldone") {
                        sessionStorage.setItem('cancelTrigger', "true");
                        sessionStorage.setItem('appliedFilter', self.globalFilter);
                        sessionStorage.setItem('appliedSBU', self.currentSBU);
                        sessionStorage.setItem('appliedBU', self.currentBU);
                        sessionStorage.setItem('appliedMU', self.currentMU);
                        sessionStorage.setItem('appliedSBUID', self.SBUID);
                        sessionStorage.setItem('appliedBUID', self.BUID);
                        sessionStorage.setItem('appliedMUID', self.MUID);
                        this.redirectTo('//UserDashboard');
                    }
                }
            }
        }, error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });

        //  sessionStorage.setItem('cancelTrigger', "true");
        //  sessionStorage.setItem('appliedFilter', self.globalFilter);
        //  sessionStorage.setItem('appliedSBU', self.currentSBU);
        //  sessionStorage.setItem('appliedBU', self.currentBU);
        //  sessionStorage.setItem('appliedMU', self.currentMU); 
        //  sessionStorage.setItem('appliedSBUID', self.SBUID);
        //  sessionStorage.setItem('appliedBUID', self.BUID);
        //  sessionStorage.setItem('appliedMUID', self.MUID);
        // // location.reload();
        // // this.router.navigate(['/UserDashboard']);
        //  this.redirectTo('//UserDashboard');
    }
    redirectTo(uri: string) {
        this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate([uri]));
    }




    radioBtnOnClick(elem) {
        this.globalAssessmentTemplateName = elem.templateName;
        this.globalAssessmentName = elem.assessmentName;
        this.globalProgramName = elem.programName;
        this.globalEngangementType = elem.engagementType;
        this.globalEffectiveDate = elem.startDate; 
        this.globalAssessmentId = elem.srNo;
        this.globalStatusId = elem.statusId;
        this.accountid = elem.accountId;
        this.globalSbuName = elem.sbu;
        this.globalBuName = elem.bu; 
        this.gloablMuName = elem.mu; 
        this.globalAccountName = elem.accountName;
        this.globalSMEName = elem.smeName;
        this.globalAccountSpocName = elem.accountSpocName;

        this.pageOneData = elem; 
    }

    viewResult() {
        this.assessmentName = this.globalAssessmentName;
        let assessmentId = this.globalAssessmentId;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        const dialogRef: MatDialogRef<ViewResultComponent> = this.dialog.open(ViewResultComponent, { panelClass: 'addAccountModal', data: { id: assessmentId, name: this.assessmentName } });

    }
    cancelReport(elem) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        const dialogRef: MatDialogRef<UserDashboardComponent> = this.dialog.open(UserDashboardComponent, { panelClass: 'cancleAccountModal', data: elem.assessmentId });
        dialogRef.afterClosed().subscribe(result => {
            //console.log(result);
            if (result === true) {
                this.myAccounts.unshift(result);
                this.getAssessmentList();
                if (result !== undefined) {
                    if (result.event === "cancel") {
                        //skip when cancel
                    } else if (result.event === "confirm") {
                        this.notification.success('Assessment has been cancelled Successfully');
                    }

                }
            }
        }, error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });
    };



    editAssessment(elem) {


        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        const dialogRef: MatDialogRef<EditAssessmentComponent> = this.dialog.open(EditAssessmentComponent, { panelClass: 'cancleAccountModal', data: { id: this.globalAssessmentId, userid: this.UserId, currentroleid: this.currentRoleId, statusId: this.globalStatusId, accountid: elem } });
        dialogRef.afterClosed().subscribe(result => {
            //console.log(result);
            if (result.status === true) {
                if (result.event === "reload") {
                    this.notification.success('The Assessment has been modified ');
                    localStorage.setItem('returnToAssessment', "true");
                    this.getAssessmentList();
                }
            }
        }, error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });
    };

    selectRow(row, i, srNo) {
        this.selectedRow = row;
        this.highlighRow(i, srNo);
    }
    highlighRow(i, srNo) {
        this.checkFunctionCount += 1;
        if (this.checkFunctionCount === 1) {
            this.radioFlag = this.dataSource.filteredData[srNo].srNo;
            setTimeout(function () {
                let yourElem = (<HTMLScriptElement[]><any>document.querySelectorAll(".radio-ticks"));
                yourElem[i].click();
            }, 10);
        } else {
            this.checkFunctionCount = 0;
        }
    }

    downloadAssessements(fileName) {
        const EXT = fileName.substr(fileName.lastIndexOf(".") + 1);
        this.assessmentlist.downloadFileAssessment({ fileName: fileName }).subscribe(
            (data) => {
                if (data !== null) {
                    saveAs(new Blob([data], { type: MIME_TYPES[EXT] }), fileName);
                    //let url = window.URL.createObjectURL(Blob);
                    this.notification.success("Assessments has been downloaded");
                }
            },
            (error) => {
                if (error.status == 404) {
                    this.notification.warn("Unable to download the Assessments");
                } else {
                    this.notification.warn(error.error.message);
                }
            }
        );
    }
      downloadReport(){
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        const dialogRef: MatDialogRef<PreviewReportComponent> = this.dialog.open(PreviewReportComponent, {  
        height: '90%',    
        width: '90%', 
        panelClass: 'cancleAccountModal', data: { 
            id: this.globalAssessmentId, 
            userid: this.UserId, 
            currentroleid: this.currentRoleId, 
            statusId: this.globalStatusId,
            pageOneObject: this.pageOneData
        } 
        });
        dialogRef.afterClosed().subscribe(result => {
            // if (result.status === true) {
            //     if (result.event === "reload") {
            //         this.notification.success('The Assessment has been modified ');
            //         localStorage.setItem('returnToAssessment', "true");
            //         this.getAssessmentList();
            //     }
            // }
        }, error => {
            if (!error.error.errorDetails) {
                this.errMessage = error.error.message;
            } else {
                this.errMessage = error.error.errorDetails[0].message;
            }
            this.notification.warn(this.errMessage);
        });
    }

    t1(){
        let filterIndex = 0;

        this.applyFilter(filterIndex);

        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
    t2(){

        let filterIndex = 1;

        this.applyFilter(filterIndex);
        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
    t3(){
        let filterIndex = 2;

        this.applyFilter(filterIndex);
        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
    t4(){
        let filterIndex = 3;

        this.applyFilter(filterIndex);
        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
    t5(){
        let filterIndex = 4;

        this.applyFilter(filterIndex);
        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
    t6(){
        let filterIndex = 5;

        this.applyFilter(filterIndex);
        localStorage.setItem('isClickedBegal', "" + true);
        localStorage.setItem('appliedBegalFilter', "" + filterIndex);

    }
  
}
