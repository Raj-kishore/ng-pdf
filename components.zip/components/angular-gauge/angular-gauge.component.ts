import { Component, OnInit, Input,AfterViewInit } from '@angular/core';
import HC_more from 'highcharts/highcharts-more' //module
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-angular-gauge',
  templateUrl: './angular-gauge.component.html',
  styleUrls: ['./angular-gauge.component.css']
})
export class AngularGaugeComponent implements OnInit, AfterViewInit {
 
  @Input() gagugeParams : {}; 
  @Input() gauge_id : any; 
  
  gauge:any;

  colorR: any;
  colorG: any;
  colorA: any;
  maxValueA: any;
  maxValueG:any;
  maxValueR:any;
  mscore: any;
  gaugeObject: any;
  maxA: any;
  maxG: any;
  maxR: any;
  mscoreColor:any;
  g_id: any; 
  constructor() { }

  ngOnInit(): void {
	   this.g_id = this.gauge_id;
  };	
	
	ngAfterViewInit(): void {
   
    
    setTimeout(()=>{    
      this.gaugeObject = this.gagugeParams;
      this.colorA = this.gaugeObject.colorA;
      this.colorG = this.gaugeObject.colorG;
      this.colorR = this.gaugeObject.colorR;
      this.maxValueA = this.gaugeObject.maxA;
      this.maxValueG = this.gaugeObject.maxG;
      this.maxValueR = this.gaugeObject.maxR;
      this.mscore = this.gaugeObject.mscore;
	 

      if (this.mscore <= 2.5) {
        this.mscoreColor = "red";
      } else if (this.mscore > 2.5 && this.mscore <= 3.5) {
        this.mscoreColor = "amber";
      } else {
        this.mscoreColor = "green";
      }

      HC_more(Highcharts);
       this.gauge = Highcharts.chart({

      chart: {
          type: 'gauge',
          renderTo: ''+this.g_id,
          width:"190",
          height:"190",
          plotBackgroundColor: null,
          plotBackgroundImage: null,
          plotBorderWidth: 0,
          plotShadow: false,
      },
      title: {
          text: ''
      },
      credits: {
          enabled: false
      },
      pane: {
          startAngle: -90,
          endAngle: 90,
          background: null
      },

      plotOptions: {
          gauge: {
              pivot: {
                  radius: 4,
                  borderWidth: 1,
                  borderColor: '#fff',
                  backgroundColor: "#000"
              },
              dial: {
                  radius: '50%',
                  backgroundColor: '#000',
                  borderColor: 'black',
                  borderWidth: 1,
                  baseWidth: 2,
                  topWidth: 2,
                  baseLength: '50%', // of radius
                  rearLength: '0%'
              }
          }
      },
      yAxis: [{
          min: 0,
          max: 5,
          minorTickInterval: 0.5,
          minorTickWidth: 1,
          minorTickLength: 8,
          minorTickPosition: 'outside',
          minorTickColor: '#666',
          tickPixelInterval: 30,
          tickWidth: 1,
          tickPosition: 'outside',
          tickLength: 8,
         
          tickColor: '#666',
          allowDecimals: false,
          labels: {
              step: 1,
              distance: 20                                
          },
          plotBands: [
          
            {
              from: this.maxValueA + 0.02,
              to: this.maxValueG,
              color: this.colorG,
            
              innerRadius: '70%'

          }, {
              from: this.maxValueR + 0.02,
              to: this.maxValueA - 0.02,
              color: this.colorA ,
              innerRadius: '70%'
          }, {
              from: 0,
              to: this.maxValueR - 0.02,
              color: this.colorR,
              innerRadius: '70%'
          }, {
              from: 0,
              to: 5,
              color: '#eaeaea',
              innerRadius: '60%',
              outerRadius: '65%'
          }
          ]
      }
   
  ],
      series: [{
          name: 'Average Maturity Index',
          type: 'gauge',
          data: [this.mscore],
          dataLabels : {
              enabled : false
          }
      }]

  }
  );
},100);
  }

}
