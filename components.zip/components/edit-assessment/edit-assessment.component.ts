import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import {ApiCommonService } from '../../../../services/api-common.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { environment } from '../../../../../environments/environment';
import { DatePipe } from '@angular/common';
import { action } from '../../../../models/account';
import { AuthenticationService } from '../../../../services/authentication.service';
import {  initiateAssessmentForm} from '../../../../models/assessment';
import {trigger, state, style, animate, transition} from '@angular/animations';
import {  Output, EventEmitter, Inject, HostListener, Optional } from '@angular/core';
import * as moment from 'moment'
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';


@Component({
  selector: 'app-edit-assessment',
  templateUrl: './edit-assessment.component.html',
  styleUrls: ['./edit-assessment.component.css'],
  animations: [
    trigger('fade', [ 
      state('open', style({
        opacity: 1,
        display:"block"
      })),
      state('closed', style({
        opacity: 0,
        display: "none"
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ])
    ])
  ],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
  }]
})
export class EditAssessmentComponent implements OnInit {
 //const moment=_moment
  currentRoleId: any;
  isLinear = true;
  initiateAssessmentForm: FormGroup;
  assessmentdata: initiateAssessmentForm[] = [];
  picker1: any;
  picker2: any;
  minDate1: Date;
  minDate2: Date;
  environment: any;
  getmyAssessments: any;
  getmyTemplates: any;
  getmySBU: any;
  getmyBU: action[] = [];
  getmySME: any;
  getmyPrograms: any;
  getmyaccountspoc: any;
  getmymarket: any;
  getprojectmembers:any;
  SBUID: any;
  mySBU : any =[];
  currentUser: any;
  UserId: {};
  myuseridstring:any;
  accountDetails: any = [];
  getmyAccounts: any;
  errMessage: any;
  errorDetails: any;
  errorDetailsShow : boolean = false;
  errorMessageShow : boolean = false;
  isOpenErr = false;
  firstStepCompleted :boolean = false;
  secondStepCompleted : boolean = false;
  asmntId: number;
  currentbuname:any;
  currentaccount:any
  muchck:boolean=false;
  sOdate: any;
  timer: any;
  userDetails: any;
  myuserid: any;
  engagementsList: any;
  engagementName: any;
  accountid:any;


  


  constructor(@Optional() @Inject(MAT_DIALOG_DATA) public data: any,private editassessmentservice: ApiCommonService,
  private assessmentRow: ApiCommonService,private fb: FormBuilder, public datepipe: DatePipe,
    private initiateAssessmentService: ApiCommonService,
    public dialogRef: MatDialogRef<EditAssessmentComponent>, private dialog: MatDialog,
    private authenticationService: AuthenticationService) {
      this.currentRoleId = localStorage.getItem('currentRoleId');


      this.environment = environment.serverUrl;
      this.currentUser = this.authenticationService.currentUserValue;
      this.myuseridstring =  parseFloat(this.currentUser.returnValue.userId.toString());
      this.myuserid = parseFloat(this.currentUser.returnValue.userId.toString());

      this.UserId =
       this.myuseridstring
      
}
ngOnInit(): void {
  this.asmntId = this.data.id;
  this.currentRoleId = localStorage.getItem('currentRoleId');
this.accountid=this.data.accountid;
  this.initiateAssessmentForm = this.fb.group({ 
      templateId:  [{ value: '', disabled: (this.currentRoleId === "8" || this.currentRoleId === "9" || this.currentRoleId === "10" ) }, Validators.required],
       assessmentName: ['', Validators.required],
       startDate: ['', Validators.required],
        sbuId:  [{ value: '', disabled: (this.currentRoleId === "8" || this.currentRoleId === "9" || this.currentRoleId === "10" ) }, Validators.required],
        buId: [{ value: '', disabled: (this.currentRoleId === "8" || this.currentRoleId === "9" || this.currentRoleId === "10" ) }, Validators.required],
        marketUnitId: [{ value: '', disabled: (this.muchck===false &&(this.currentRoleId === "8" || this.currentRoleId === "9" || this.currentRoleId === "10") ) }, Validators.required],
        accountId:  [{ value: '', disabled: (this.currentRoleId === "8" || this.currentRoleId === "9" || this.currentRoleId === "10" ) }, Validators.required],
        smeUserId: ['', Validators.required],
        accountSpocId: ['', Validators.required],
        teamMembersIds: ['', Validators.required],
        readyToUse: 'true',
        statusId:this.data.statusId,
        programId: ['', Validators.required],
        engagementId: ['', Validators.required],
      });
    this.assessmentdata = this.initiateAssessmentForm.value;

    // setTimeout(
    //   (x)=>{
    //     this.getEngagements() 
    //   }
    //  , 300);
    this.getinitiateAssessment();
    this.getPrograms();
     this.getEngagements() ;

  
}

  changeSBUs(mySBU, id) {
    this.getmyBU =[];
 //   this.engagementsList =[];

    this.SBUID = id;
    for (let i = 0; i < mySBU.length; i++) {
      if (mySBU[i].sbuId == this.SBUID) {
        for (let j = 0; j < mySBU[i].bus.length; j++) {
          let q: action = {value: mySBU[i].bus[j].buId, viewValue: mySBU[i].bus[j].buName};
          this.getmyBU.push(q);
        }
      }
    }
  }
  changeBUS() {
   // this.engagementsList =[];
  }


  getAccounts(sbuid,buid,muid) {

    this.getmyAccounts = [];
    //this.engagementsList =[];

    console.log(this.initiateAssessmentForm);
    this.accountDetails = {
      sbuId: sbuid,
      buId: buid,
      marketUnitId: muid
    }
    if(this.accountDetails.sbuId && this.accountDetails.buId && this.accountDetails.marketUnitId) { 
    this.initiateAssessmentService.insertRequest(`${environment.serverUrl}/accounts/init`, 'POST', this.accountDetails)
    //this.assessmentlist.getRequest(`../../../assets/json/assessmenttemplates.json`, 'GET')
      .subscribe(data => {
        this.getmyAccounts = data.returnValue;
      },
      error => {
        this.isOpenErr = true;
        this.errorDetails = [];
        //setTimeout(()=>{ this.isOpenErr = false; }, 3000);
        if(!error.error.errorDetails) {
          this.errorMessageShow = true;
          setTimeout(()=>{ this.isOpenErr = false; }, 3000);
          this.errMessage = error.error.message;
        }
        else {
          setTimeout(()=>{ this.isOpenErr = false; }, 5000);
          this.errorDetailsShow = true;
          this.errorDetails = [];
          this.errorDetails = error.error.errorDetails;
          // for (let i = 0; i < error.error.errorDetails.length; i++) {
          //   this.errMessage.push(error.error.errorDetails[i].message)
          // }
        }
      });
    }
  }

  stepperNext1() {
    this.firstStepCompleted = true;
  }

  stepperNext2() {
    this.secondStepCompleted = true;
  }

  getinitiateAssessment() {
      this.initiateAssessmentService.insertRequest(`${environment.serverUrl}/assessments/initpage`, 'POST', {userId:this.UserId})
    //this.assessmentlist.getRequest(`../../../assets/json/assessmenttemplates.json`, 'GET')
      .subscribe(data => {
        this.getmyAssessments = data.returnValue;
        this.getmyTemplates = [];
        this.getmySBU = data.returnValue.sbu;
        this.getmySME = data.returnValue.smeusers;
        this.getmyaccountspoc = data.returnValue.accountspocs;
        this.getmymarket = data.returnValue.marketUnit;
        this.getprojectmembers = data.returnValue.projectmembers;
        data.returnValue.assessTemp.forEach((Titem, Tindex) => {
          if(Titem.readyForUse == true) {
            this.getmyTemplates.push(Titem);
          }
        })
     this.getassessmentData();
     this.getprogramData();

      },

      error => {
        this.isOpenErr = true;
        this.errorDetails = [];
        //setTimeout(()=>{ this.isOpenErr = false; }, 3000);
        if(!error.error.errorDetails) {
          this.errorMessageShow = true;
          setTimeout(()=>{ this.isOpenErr = false; }, 3000);
          this.errMessage = error.error.message;
        }
        else {
          setTimeout(()=>{ this.isOpenErr = false; }, 5000);
          this.errorDetailsShow = true;
          this.errorDetails = [];
          this.errorDetails = error.error.errorDetails;
          // for (let i = 0; i < error.error.errorDetails.length; i++) {
          //   this.errMessage.push(error.error.errorDetails[i].message)
          // }
        }
      });
  }

  getPrograms() {
    this.initiateAssessmentService.getRequest(`${environment.serverUrl}/assessments/programs`, 'GET')
    //this.assessmentlist.getRequest(`../../../assets/json/assessmenttemplates.json`, 'GET')
      .subscribe(data => {
        this.getmyPrograms = data.returnValue;
      },
      error => {
        this.isOpenErr = true;
        this.errorDetails = [];
        //setTimeout(()=>{ this.isOpenErr = false; }, 3000);
        if(!error.error.errorDetails) {
          this.errorMessageShow = true;
          setTimeout(()=>{ this.isOpenErr = false; }, 3000);
          this.errMessage = error.error.message;
        }
        else {
          setTimeout(()=>{ this.isOpenErr = false; }, 5000);
          this.errorDetailsShow = true;
          this.errorDetails = [];
          this.errorDetails = error.error.errorDetails;
          // for (let i = 0; i < error.error.errorDetails.length; i++) {
          //   this.errMessage.push(error.error.errorDetails[i].message)
          // }
        }
      });
  }
  getEngagements() {
    
    this.userDetails = {
      userId: this.myuserid,
      currentRole: this.currentRoleId,
     accountId: this.accountid

    }
    this.initiateAssessmentService.insertRequest(`${environment.serverUrl}/accounts/engagements/list`, 'POST', this.userDetails)
    //this.assessmentlist.getRequest(`../../../assets/json/assessmenttemplates.json`, 'GET')
      .subscribe(data => {
        this.engagementsList = data.returnValue.engagements;
      },
      error => {
        this.isOpenErr = true;
        this.errorDetails = [];
        if(!error.error.errorDetails) {
          this.errorMessageShow = true;
          setTimeout(()=>{ this.isOpenErr = false; }, 3000);
          this.errMessage = error.error.message;
        }
        else {
          setTimeout(()=>{ this.isOpenErr = false; }, 5000);
          this.errorDetailsShow = true;
          this.errorDetails = [];
          this.errorDetails = error.error.errorDetails;
        }
      });
  }

  selectEngagement(event) {
    this.engagementName = event.source.selected._element.nativeElement.innerText.trim();
    this.initiateAssessmentForm.value.engagementName = this.engagementName;
  }

editAssessment(){
  this.initiateAssessmentForm.value.startDate =this.datepipe.transform(this.picker1, 'dd-MM-yyyy');

  let data = {
    "assessmentId":this.asmntId,
    "userId":this.UserId,
    "currentRoleId": this.currentRoleId,
    "assessmentName":""+ this.initiateAssessmentForm.controls['assessmentName'].value,
    "startDate":""+ this.datepipe.transform(this.picker1, 'dd-MM-yyyy'),
    "statusId":""+ this.initiateAssessmentForm.controls['statusId'].value,
    "smeUserId":""+ this.initiateAssessmentForm.controls['smeUserId'].value,
    "accountSpocId":""+this.initiateAssessmentForm.controls['accountSpocId'].value,
    "teamMembersIds":this.initiateAssessmentForm.controls['teamMembersIds'].value.toString().split(',').map(Number),
    "engagementId":""+ this.initiateAssessmentForm.controls['engagementId'].value,
    "programId":""+ this.initiateAssessmentForm.controls['programId'].value,
  }
  console.log(data);
  this.editassessmentservice.partialRequest(`${environment.serverUrl}/assessments/init`, 'PATCH', data)
  .subscribe(data => {
    console.log(data);
    if (data.success === true) {
      this.dialogRef.close({ event: 'reload', status: true });
    } else {
      this.dialogRef.close({ event: 'reload', status: false });
    }
    console.log(data);

  },
  error => {
    this.isOpenErr = true;
    this.errorDetails = [];
        if(!error.error.errorDetails) {
          this.errorMessageShow = true;
          setTimeout(()=>{ this.isOpenErr = false; }, 3000);
          this.errMessage = error.error.message;
        }
        else {
          setTimeout(()=>{ this.isOpenErr = false; }, 5000);
          this.errorDetailsShow = true;
          this.errorDetails = [];
          this.errorDetails = error.error.errorDetails;
         
        }
  });
console.log(this.initiateAssessmentForm.value);
}
  cancel() {
     this.dialogRef.close({event:'cancel'});
   }

   startEvent(type: string, event: MatDatepickerInputEvent<Date>){
    this.picker1 = event.value;
    let track = this.minDate2;
    this.minDate2 = this.picker1;
    
    const currentYear = new Date().getFullYear();
  }
  endEvent(type: string, event: MatDatepickerInputEvent<Date>){
    this.picker2 =   event.value;
  }

  getTeamMembers(x){
    let id=[];
   if(x && x.length){
    for(var i=0; i<x.length;i++){
      id.push(x[i].id);
    }
   }
   return id;
  }
getassessmentData(){
  this.assessmentRow.insertRequest(`${environment.serverUrl}/assessments/viewinit`, 'POST', {assessmentId: this.asmntId ,userId:this.UserId ,currentRoleId:this.currentRoleId}).subscribe(response => {
     
    console.log('id');
    if (response.success === true) {
      this.initiateAssessmentForm.controls['templateId'].setValue(response.returnValue.template.templateId);
      this.initiateAssessmentForm.controls['assessmentName'].setValue(response.returnValue.assessment.assessmentName);

      let sdateParts = response.returnValue.assessment.startDate.split("-");
      this.sOdate = new Date(+sdateParts[2], sdateParts[1] - 1, +sdateParts[0]); 
      this.picker1 = new Date(this.sOdate);
     this.initiateAssessmentForm.controls['startDate'].setValue(this.picker1);

      this.initiateAssessmentForm.controls['sbuId'].setValue(response.returnValue.sbu.sbuId);   
      //this.getinitiateAssessment();   
           this.changeSBUs(this.getmySBU,response.returnValue.sbu.sbuId);
      this.currentbuname=response.returnValue.bu.buName;
      this.initiateAssessmentForm.controls['buId'].setValue(response.returnValue.bu.buId);
      this.initiateAssessmentForm.controls['marketUnitId'].setValue(response.returnValue.marketUnit.marketUnitId);
      this.muchck=false;
     
      this.currentaccount=response.returnValue.account.accountName;
       this.getAccounts(response.returnValue.sbu.sbuId,response.returnValue.bu.buId,response.returnValue.marketUnit.marketUnitId);
      this.initiateAssessmentForm.controls['accountId'].setValue(response.returnValue.account.accountId);
     

      if(response.returnValue.accountSpoc){
        this.initiateAssessmentForm.controls['accountSpocId'].setValue(response.returnValue.accountSpoc.id);

      }
      let teammemberid= this.getTeamMembers(response.returnValue.teamMembers);
    
      this.initiateAssessmentForm.controls['teamMembersIds'].setValue(teammemberid);
      if(response.returnValue.smeUser){
      this.initiateAssessmentForm.controls['smeUserId'].setValue(response.returnValue.smeUser.id);    
      }     
    } else {
      console.log("Error in SBUs fetching :", response.message)
    }
  },
  error => {
    this.isOpenErr = true;
    this.errorDetails = [];
    //setTimeout(()=>{ this.isOpenErr = false; }, 3000);
    if(!error.error.errorDetails) {
      this.errorMessageShow = true;
      setTimeout(()=>{ this.isOpenErr = false; }, 3000);
      this.errMessage = error.error.message;
    }
    else {
      setTimeout(()=>{ this.isOpenErr = false; }, 5000);
      this.errorDetailsShow = true;
      this.errorDetails = [];
      this.errorDetails = error.error.errorDetails;
      // for (let i = 0; i < error.error.errorDetails.length; i++) {
      //   this.errMessage.push(error.error.errorDetails[i].message)
      // }
    }
  });
}
getprogramData(){
  this.assessmentRow.insertRequest(`${environment.serverUrl}/assessments/view`, 'POST', {assessmentId: this.asmntId ,userId:this.UserId ,currentRoleId:this.currentRoleId}).subscribe((response => {  if (response.success === true) {
         this.initiateAssessmentForm.controls['programId'].setValue(response.returnValue.program.programId);
     this.initiateAssessmentForm.controls['engagementId'].setValue(response.returnValue.accountEngagement.engagementId);
  }
}),
error => {
  this.isOpenErr = true;
  this.errorDetails = [];
  //setTimeout(()=>{ this.isOpenErr = false; }, 3000);
  if(!error.error.errorDetails) {
    this.errorMessageShow = true;
    setTimeout(()=>{ this.isOpenErr = false; }, 3000);
    this.errMessage = error.error.message;
  }
  else {
    setTimeout(()=>{ this.isOpenErr = false; }, 5000);
    this.errorDetailsShow = true;
    this.errorDetails = [];
    this.errorDetails = error.error.errorDetails;
    // for (let i = 0; i < error.error.errorDetails.length; i++) {
    //   this.errMessage.push(error.error.errorDetails[i].message)
    // }
  }
});
}

keyPressNumbers(event) {
  var charCode = (event.which) ? event.which : event.keyCode;
  // Only Numbers 0-9
  if ((charCode < 48 || charCode > 57)) {
    event.preventDefault();
    return false;
  } else {
    return true;
  }
}
}







