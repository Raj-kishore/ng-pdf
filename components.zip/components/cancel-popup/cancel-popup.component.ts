
import { Component, OnInit, Output, EventEmitter, Inject, HostListener, Optional } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiCommonService } from '../../../../services/api-common.service';
import { environment } from '../../../../../environments/environment';
import { action } from '../../../../models/account';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-cancel-popup',
  templateUrl: './cancel-popup.component.html',
  styleUrls: ['./cancel-popup.component.css'],
  animations: [
    trigger('fade', [
      state('open', style({
        opacity: 1,
        display: "block"
      })),
      state('closed', style({
        opacity: 0,
        display: "none"
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ])
    ])
  ]
})
export class CancelPopupComponent implements OnInit {


  UserNameVal: any;
  isOpenErr = false;
  errorMsg:any;
  accountId: number;
  deletionNote: string;
  name: string;
  deletion_note: string = "";
  constructor(@Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<CancelPopupComponent>, private userDelete: ApiCommonService) { }

  ngOnInit(): void {
    //console.log("DATA >>> "+JSON.stringify(this.data));
    this.accountId = parseInt(this.data.id);
  }

  cancel() {
    this.dialogRef.close({ event: 'cancel' });
  }

  delete() {
    // const options = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/json'
    //   }),
    //   body: {
    //     "assessmentId": this.accountId,
    //     "deletionNote": "" + this.deletion_note,
    //   }
    // }
    const options = {
      "assessmentId": this.accountId,
      "assessmentStatusId":6, 
      "cancellationReason":"" + this.deletion_note 
    };
    this.userDelete.partialRequest(environment.serverUrl + '/assessments/changestatus', '', options).subscribe((response => {
      if (response.success === true) {
        console.log("Successful while delete => msg :", response.message)
        this.dialogRef.close({ event: 'canceldone', status: true });
      }
    }),
      (error) => {
        this.isOpenErr = true;
        setTimeout(() => { this.isOpenErr = false; }, 3000);
        this.errorMsg = error.error;
      });
  }

}
