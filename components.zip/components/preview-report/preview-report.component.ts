import { Component, OnInit,  Optional, Inject, ViewChild, ElementRef , AfterViewInit  } from '@angular/core';
import { jsPDF } from "jspdf";
import html2canvas from 'html2canvas';
import { MatTableDataSource } from '@angular/material/table';
import { ApiCommonService } from '../../../../services/api-common.service';
import { environment } from '../../../../../environments/environment'
import { MatDialogRef } from '@angular/material/dialog';
import autoTable from 'jspdf-autotable';

//declare var jsPDF: any;
//import 'jspdf-autotable';	
import {  MAT_DIALOG_DATA } from '@angular/material/dialog';
declare var $: any;

export interface CustomWindow extends Window {
  customAttribute: any;
}
export interface PeriodicElement {
  key: string;
  value: string;
}

export interface AssessmentDetailsModel {
  srNo: string;
  Dimension: string;
  WorkArea: string;
  Activity: string; 
  Response: string; 
  Comment: string; 
  Score: string; 
}

// export interface AssessmentDetails{
//   assessmentTemplatekey: any; 
//   assessmentkey: any;
//   program: any; 
//   engagementType: any; 
//   effectiveDate: any; 
// }

// export interface AccountDetails{
//   sbukey: any; 
//   bukey: any;
//   mukey: any; 
//   accountkey: any;
// }

// export interface roleDetails{
//   smekey: any; 
//   accountSpocName : any; 
// }

const ELEMENT_DATA: PeriodicElement[] = [
  { key: 'Assessment Template Name', value: 'H' },
  { key: 'Assessment Name', value: 'H' },
  { key: 'Program', value: 'H' },
  { key: 'Engagement Type', value: 'H' },
  { key: 'Effective Date', value: 'H' },
];

const ELEMENT_DATA2: PeriodicElement[] = [
  { key: 'SBU Name', value: 'H' },
  { key: 'BU Name', value: 'H' },
  { key: 'Market Unit', value: 'H' },
  { key: 'Account Name', value: 'H' }
];

const ELEMENT_DATA3: PeriodicElement[] = [
  { key: 'SME Name', value: 'H' },
  { key: 'Account SPOC Name', value: 'H' }
];
@Component({
  selector: 'app-preview-report',
  templateUrl: './preview-report.component.html',
  styleUrls: ['./preview-report.component.css']
})
export class PreviewReportComponent implements OnInit, AfterViewInit {

  @ViewChild('mainScreen') elementView: ElementRef;
  viewHeight: number;
  
  title = 'html-to-pdf-poc-sprint16';
  client_name = "Coca - cola";
  displayedColumns: string[] = ['name', 'symbol'];
  displayedColumnsD: string[] = ['srno', 'dimension', 'workarea', 'score'];
  displayedColumnsE: string[] = ['srno', 'dimension', 'workarea','activity','response','comment', 'score'];
  dataSource = ELEMENT_DATA;
  dataSource2 = ELEMENT_DATA2;
  dataSource3 = ELEMENT_DATA3;
  pdf_height:any; 
  pagewidth: any; 
  pageheight: any; 
  gagugeParams:any; 
  globalAssessmentId: any;
  globalAssessmentName: any;
    globalAssessmentTemplateName:any;
    globalProgramName: any;
    globalEngangementType: any;
    globalEffectiveDate: any;
    globalSbuName: any;
    globalBuName: any;
    gloablMuName: any;
    globalAccountName: any;
    globalSMEName: any;
    globalAccountSpocName: any;
    globalStatusId: any;
    globalElem: any;
    globalAccountid: any; 
    ASSESSMENT_DATA = {} as PeriodicElement; 
    dataSourceA: any = [];
    dataSourceB: any = [];
    dataSourceC: any = [];
    dataSourceD: any = [];
    dataSourceE: any = [];
    errMessage: any;
    rwHeight:any; 
	  minValue: any;
  midValue: any;
  maxValue: any;
  ngAfterViewInit(): void {
   
    var standard_ratio = 1; 
    this.pagewidth = document.getElementById("assessment-information").offsetWidth;
    



 
    //this.pageheight =   document.getElementById("assessment-information").offsetHeight;
    //var standard_ratio = Number(this.pagewidth)/Number(this.pageheight); 
    this.pageheight = Math.floor(this.pagewidth/standard_ratio); 

    
    // document.getElementById("assessment-information").style.height = this.pageheight+"px"; 
    // document.getElementById("assessment-result").style.height = this.pageheight+"px"; 
    // document.getElementById("assessment-details").style.height = this.pageheight+"px"; 

	


  }
  constructor(@Optional() @Inject(MAT_DIALOG_DATA) public data: any,
  private apicommonservice: ApiCommonService
  ) {
    


  }

  ngOnInit(): void {
  
    this.data = this.data.pageOneObject;
    this.globalAssessmentTemplateName = this.data.templateName;
    this.globalAssessmentName = this.data.assessmentName;
    this.globalProgramName = this.data.programName;
    this.globalEngangementType = this.data.engagementType;
    this.globalEffectiveDate = this.data.startDate; 
    this.globalAssessmentId = this.data.srNo;
    this.globalStatusId = this.data.statusId;
    this.globalAccountid = this.data.accountId;
    this.globalSbuName = this.data.sbu;
    this.globalBuName = this.data.bu; 
    this.gloablMuName = this.data.mu; 
    this.globalAccountName = this.data.accountName;
    this.globalSMEName = this.data.smeName;
    this.globalAccountSpocName = this.data.accountSpocName;

    let localAssessmentObjA: PeriodicElement[] = [];
    localAssessmentObjA.push({
      "key":'Assessment Template Name',
      "value": this.globalAssessmentTemplateName
    });
    localAssessmentObjA.push({
      "key":'Assessment Name',
      "value": this.globalAssessmentName
    });
    localAssessmentObjA.push({
      "key":'Program',
      "value": this.globalProgramName
    });
    localAssessmentObjA.push({
      "key":'Engagement Type',
      "value": this.globalEngangementType
    });
    localAssessmentObjA.push({
      "key":'Effective Date',
      "value": this.globalEffectiveDate
    });
    this.dataSourceA = new MatTableDataSource<PeriodicElement>(localAssessmentObjA);
    
    
    
    let localAssessmentObjB: PeriodicElement[] = [];
    localAssessmentObjB.push({
      "key":'SBU Name',
      "value": this.globalSbuName
    });
    localAssessmentObjB.push({
      "key":'BU Name',
      "value": this.globalBuName
    });
    localAssessmentObjB.push({
      "key":'Market Unit',
      "value": this.gloablMuName
    });
    localAssessmentObjB.push({
      "key":'Account Name',
      "value": this.globalAccountName
    });
    this.dataSourceB = new MatTableDataSource<PeriodicElement>(localAssessmentObjB);

    let localAssessmentObjC: PeriodicElement[] = [];
    localAssessmentObjC.push({
      "key":'SME Name',
      "value": this.globalSMEName
    });
    localAssessmentObjC.push({
      "key":'Account SPOC Name',
      "value": this.globalAccountSpocName
    });
    this.dataSourceC = new MatTableDataSource<PeriodicElement>(localAssessmentObjC);



    let localAssessmentObjD: AssessmentDetailsModel[] = [];
    let assessmentID = {
      "assessmentId": ""+ this.globalAssessmentId
    }
    this.apicommonservice.insertRequest(`${environment.serverUrl}/assessments/results`, 'POST', assessmentID)

    .subscribe(data => {
		
		
		this.minValue = data.returnValue.ragRanges.maxValueR;
        this.midValue = data.returnValue.ragRanges.maxValueA;
        this.maxValue = data.returnValue.ragRanges.maxValueG;
		
      this.gagugeParams = {
        "colorA":data.returnValue.categoryColourCode.colourCodeA,
        "colorG":data.returnValue.categoryColourCode.colourCodeG,
        "colorR":data.returnValue.categoryColourCode.colourCodeR,
        "maxA":data.returnValue.ragRanges.maxValueA,
        "maxG":data.returnValue.ragRanges.maxValueG,
        "maxR":data.returnValue.ragRanges.maxValueR,
        "mscore":data.returnValue.overallScore,
      }
	  
	  data.returnValue.dimensions.sort((a,b)=>{
		  return a.displayorder - b.displayorder;  
	  }); 
	   data.returnValue.dimensions.map(x=>{
		   
		   x.workAreas.sort((a,b)=>{
		  return a.displayorder - b.displayorder;  
	  });
	   });
	  
	  
         data.returnValue.dimensions.map((res,indx)=>{

          localAssessmentObjD.push({  
            "srNo": ""+ (indx+1) +". ",
            "Dimension": res.dimensionName,
            "WorkArea": "Overall",
            "Activity":"",
            "Response": "",
            "Comment":"",
            "Score": res.dimensionScore 
          });
		  
          res.workAreas.map(x=>{
            localAssessmentObjD.push({  
              "srNo": "",
              "Dimension":"",
              "WorkArea": x.workAreaName,
              "Activity":"",
              "Response": "",
              "Comment":"",
              "Score": x.workareascore
            });
          });
		  
        });

        this.dataSourceD = new MatTableDataSource<AssessmentDetailsModel>(localAssessmentObjD);
        console.log(this.dataSourceD);
    },
    error => {
      this.errMessage = error.error;
    });




    let localAssessmentObjE: AssessmentDetailsModel[] = [];
     this.apicommonservice.insertRequest(`${environment.serverUrl}/assessments/get`, 'POST', assessmentID)
    .subscribe(data => {
        let temp_srno = -1;
        let temp_dimension = "";
        let temp_workarea = "";
		
		
			  data.returnValue.template.dimensions.sort((a,b)=>{
		  return a.displayorder - b.displayorder;  
	  }); 
	   data.returnValue.template.dimensions.map(x=>{
		   
		   x.workAreas.sort((a,b)=>{
		  return a.displayorder - b.displayorder;  
	  });
	   });
	   
	    data.returnValue.template.dimensions.map(x=>{
		   
		   x.workAreas.map(y=>{
		      y.activities.sort((a,b)=>{
		  return a.displayorder - b.displayorder;  
	  });
	  });
	   });
		
		
				data.returnValue.template.dimensions.map((res1,indx)=>{
        
		res1.workAreas.map(res2=>{
            res2.activities.map(res3=>{
                  res3.responses.map(res4=>{
                    if(res4.responseId === res3.selectedResponseId){
                      if(temp_srno !== (indx + 1)){
                        if(temp_dimension !== res1.dimensionName){
                          if(temp_workarea !== res2.workAreaName){
                            localAssessmentObjE.push({
                              "srNo": ""+ (indx+1) +". ",
                              "Dimension":res1.dimensionName,
                              "WorkArea": res2.workAreaName,
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }else{
                            localAssessmentObjE.push({
                              "srNo": ""+ (indx+1) +". ",
                              "Dimension":res1.dimensionName,
                              "WorkArea": " ",
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }

                        }else{
                          if(temp_workarea !== res2.workAreaName){
                            localAssessmentObjE.push({
                              "srNo": ""+ (indx+1) +". ",
                              "Dimension":" ",
                              "WorkArea": res2.workAreaName,
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }else{
                            localAssessmentObjE.push({
                              "srNo": ""+ (indx+1) +". ",
                              "Dimension":" ",
                              "WorkArea": " ",
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }
             
                        }
             
                      }else{

                        if(temp_dimension !== res1.dimensionName){
                          if(temp_workarea !== res2.workAreaName){
                            localAssessmentObjE.push({
                              "srNo": " ",
                              "Dimension":res1.dimensionName,
                              "WorkArea": res2.workAreaName,
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }else{
                            localAssessmentObjE.push({
                              "srNo": " ",
                              "Dimension":res1.dimensionName,
                              "WorkArea": " ",
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }
   
                        }else{
                          if(temp_workarea !== res2.workAreaName){
                            localAssessmentObjE.push({
                              "srNo": " ",
                              "Dimension": " ",
                              "WorkArea": res2.workAreaName,
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }else{
                            localAssessmentObjE.push({
                              "srNo": " ",
                              "Dimension": " ",
                              "WorkArea": " ",
                              "Activity":res3.activityName,
                              "Response": res4.responseDescription,
                              "Comment":res3.comment,
                              "Score": (res3.newScore === -1)?0:res3.newScore
                            });
                          }
                 
                        }
                 
                      }
                      temp_srno = indx + 1;
                      temp_dimension = res1.dimensionName;
                      temp_workarea = res2.workAreaName;
                    }
                });
            });
          });
        });
      this.dataSourceE = new MatTableDataSource<AssessmentDetailsModel>(localAssessmentObjE);
      console.log(this.dataSourceE);
     },
     error => {
       this.errMessage = error.error;
     });




  }

  download() { 
   //document.getElementById("rw").style.display = "block";

    // window.scrollTo(0,0);
     // https://stackoverflow.com/questions/19272933/jspdf-multi-page-pdf-with-html-renderer
     //window.print();
     let root = this; 
     setTimeout(function () {
       var imgData1 = undefined;
       var imgData2 = undefined;
       var imgData3 = undefined; 
 
       var doc = new jsPDF('l', 'px',[root.pagewidth, root.pageheight]);
 
       html2canvas(document.querySelector("#assessment-information"),{
         scrollX: 0,
         scrollY: -window.scrollY
     }).then(canvas => {
         //$("#previewBeforeDownload").html(canvas);
         imgData1 = canvas.toDataURL("image/jpeg",1);
       
         
         let pageWidth = doc.internal.pageSize.getWidth();
         let pageHeight = doc.internal.pageSize.getHeight();
         console.log(canvas.width +" "+ document.getElementById("assessment-information").offsetWidth+" "+document.getElementById("assessment-information").clientWidth+"  "+ document.getElementById("assessment-information").scrollWidth);
         console.log(canvas.height + " "+ document.getElementById("assessment-information").offsetHeight+" "+document.getElementById("assessment-information").clientHeight+ " "+ document.getElementById("assessment-information").scrollHeight);
       //  let imageWidth = canvas.width;
       //  let imageHeight = canvas.height;
         let imageWidth = pageWidth;
         let imageHeight =pageHeight;
         let ratio = imageWidth/imageHeight >= pageWidth/pageHeight ? pageWidth/imageWidth : pageHeight/imageHeight;
         
         //Set margin auto (Less than 1280 resolution)
          const widthRatio = pageWidth / canvas.width;
          const heightRatio = pageHeight / canvas.height;
         const ratioCanvas = widthRatio > heightRatio ? heightRatio : widthRatio;
         const canvasWidth = canvas.width * ratio;
         const canvasHeight = canvas.height * ratio;
         const marginX = (pageWidth - canvasWidth) / 2;
         const marginY = (pageHeight - canvasHeight) / 2;
         
        // doc.addImage(imgData1, 'PNG', 0, 0, 210, 297); // A4 sizes
         // doc.addImage( imgData2, 'PNG', 0, 90, 210, 297); // img1 and img2 on first page
 
     //    doc.addImage(imgData1, 'JPEG', marginX, marginY, imageWidth * ratio, imageHeight * ratio );
     doc.addImage(imgData1, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio );
 
 
         doc.addPage();

         


       html2canvas(document.querySelector("#assessment-result"),{
        scrollX: 0,
        scrollY: -window.scrollY
    }).then(canvas => {
             //$("#previewBeforeDownload").html(canvas);
             imgData2 = canvas.toDataURL('image/jpeg',1);
 
     
             let pageWidth = doc.internal.pageSize.getWidth();
             let pageHeight = doc.internal.pageSize.getHeight();
                   //  let imageWidth = canvas.width;
           //  let imageHeight = canvas.height;
             let imageWidth = pageWidth;
             let imageHeight =pageHeight;
             let ratio = imageWidth/imageHeight >= pageWidth/pageHeight ? pageWidth/imageWidth : pageHeight/imageHeight;
             
             //Set margin auto (Less than 1280 resolution)
              const widthRatio = pageWidth / canvas.width;
              const heightRatio = pageHeight / canvas.height;
             const ratioCanvas = widthRatio > heightRatio ? heightRatio : widthRatio;
             const canvasWidth = canvas.width * ratio;
             const canvasHeight = canvas.height * ratio;
             const marginX = (pageWidth - canvasWidth) / 2;
             const marginY = (pageHeight - canvasHeight) / 2;
             
            // doc.addImage(imgData1, 'PNG', 0, 0, 210, 297); // A4 sizes
             // doc.addImage( imgData2, 'PNG', 0, 90, 210, 297); // img1 and img2 on first page
     
         //    doc.addImage(imgData1, 'JPEG', marginX, marginY, imageWidth * ratio, imageHeight * ratio );
         doc.addImage(imgData2, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio );
     
     
           //  doc.addImage(imgData2, 'PNG', 0, 0, 210, 297); // img3 on second page
           doc.addImage(imgData2, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio);

        doc.addPage();

        
     html2canvas(document.querySelector("#assessment-details"),{
      scrollX: 0,
      scrollY: -window.scrollY
  }).then(canvas => {
      //$("#previewBeforeDownload").html(canvas);
      imgData3 = canvas.toDataURL('image/jpeg',1);

  
      let pageWidth = doc.internal.pageSize.getWidth();
      let pageHeight = doc.internal.pageSize.getHeight();
      console.log(canvas.width +" "+ document.getElementById("assessment-information").offsetWidth+" "+document.getElementById("assessment-information").clientWidth+"  "+ document.getElementById("assessment-information").scrollWidth);
      console.log(canvas.height + " "+ document.getElementById("assessment-information").offsetHeight+" "+document.getElementById("assessment-information").clientHeight+ " "+ document.getElementById("assessment-information").scrollHeight);
    //  let imageWidth = canvas.width;
    //  let imageHeight = canvas.height;
      let imageWidth = pageWidth;
      let imageHeight =pageHeight;
      let ratio = imageWidth/imageHeight >= pageWidth/pageHeight ? pageWidth/imageWidth : pageHeight/imageHeight;
      
      //Set margin auto (Less than 1280 resolution)
       const widthRatio = pageWidth / canvas.width;
       const heightRatio = pageHeight / canvas.height;
      const ratioCanvas = widthRatio > heightRatio ? heightRatio : widthRatio;
      const canvasWidth = canvas.width * ratio;
      const canvasHeight = canvas.height * ratio;
      const marginX = (pageWidth - canvasWidth) / 2;
      const marginY = (pageHeight - canvasHeight) / 2;
      
     // doc.addImage(imgData1, 'PNG', 0, 0, 210, 297); // A4 sizes
      // doc.addImage( imgData2, 'PNG', 0, 90, 210, 297); // img1 and img2 on first page

  //    doc.addImage(imgData1, 'JPEG', marginX, marginY, imageWidth * ratio, imageHeight * ratio );
  doc.addImage(imgData3, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio );


    //  doc.addImage(imgData2, 'PNG', 0, 0, 210, 297); // img3 on second page
    doc.addImage(imgData3, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio);

      doc.save("file.pdf");
   
    });
      });



       });









 
 
     }, 1000);
   }
   // download(){
   //   //window.print();
   //   setTimeout(function () {
   //     html2canvas(document.querySelector(".report-wrapper")).then(canvas => {
   //         //$("#previewBeforeDownload").html(canvas);
   //         var imgData = canvas.toDataURL("image/jpeg",1);
 
 
   //         var pdf = new jsPDF("p", "mm", "a4");
   //         var pageWidth = pdf.internal.pageSize.getWidth();
   //         var pageHeight = pdf.internal.pageSize.getHeight();
   //         var imageWidth = canvas.width;
   //         var imageHeight = canvas.height;
   //         var ratio = imageWidth/imageHeight >= pageWidth/pageHeight ? pageWidth/imageWidth : pageHeight/imageHeight;
   //         //pdf = new jsPDF(this.state.orientation, undefined, format);
   //         pdf.addImage(imgData, 'JPEG', 0, 0, imageWidth * ratio, imageHeight * ratio);
   //         pdf.save("report.pdf");
   //     });
   //   },1000);
   // }
   cancel() {
	   	let ee =  document.getElementById("rw");
	   var rect = ee.getBoundingClientRect();
  let m = rect.left;
  let n = rect.top; // how far from the top of the view port
  let o = rect.width;
  let g = rect.height;
	
	alert(m+" ... "+n+" ... "+o+" ... "+g); //102 -599
   
	alert(document.getElementById("t4ref").getBoundingClientRect().top); //1023 321z
	
	alert(document.getElementById("t4ref").getBoundingClientRect().top - n );
    // this.dialogRef.close({ event: 'cancel' });
}



winPrint(){
  // var printContents = document.getElementsByClassName("report-wrapper")[0].innerHTML;
  // var originalContents = document.body.innerHTML;
  // document.body.innerHTML = printContents; 

  // w = window.open();
  //console.log(document.getElementById("rw").innerHTML());
  // w.document.write(document.querySelector("#rw").innerHTML());

  //  w.print();
  //  w.close();
  // document.body.innerHTML = originalContents; 
  // var doc = new jsPDF('p', 'mm');
  // html2canvas(document.querySelector("#rw"),{
  //   scrollX: 0,
  //   scrollY: -window.scrollY
  // }).then(canvas => {

  //   var imgData = canvas.toDataURL('image/png');
  //   alert(this.rwHeight);

  // });



}

 getPosition(el) {

    var x = null,
        y = null ;

    while (el != null && (el.tagName || '').toLowerCase() != 'html') {
        x += el.offsetLeft || 0; 
        y += el.offsetTop || 0;
        el = el.parentElement;
    }

    return { x: parseInt(x, 10), y: parseInt(y, 10) };
  }
  download2(){
	  

	
   
    let useHeight = document.getElementById("rw").scrollHeight;
    // var logoImg = 'data:image/jpeg;base64,'+ Base64.encode('');
    html2canvas(document.querySelector("#rw"), {
      height: useHeight,
      scrollX: 0,
      scrollY: -window.scrollY
    }).then(canvas => {	
	
	 html2canvas(document.querySelector("#logo"), {
      scrollX: 0,
      scrollY: -window.scrollY
    }).then(canvas2 => {	
      
      var imgData = canvas.toDataURL('image/png');
	  var imgData2 = canvas2.toDataURL('image/png');
	  
	  var margin = 14;
	  var imgWidth = 210 - 2*margin; 
	  var pageHeight = 295; 
	  var imgHeight = canvas.height * imgWidth / canvas.width; 
	  var heightLeft = imgHeight; 
	  var doc = new jsPDF('p', 'mm');
	  var position = 10; // give some top padding to first page
	  doc.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
	  doc.addImage(imgData2, 'PNG', 1, pageHeight-8, pageWidth, 0);
	  heightLeft -= pageHeight;
	  
	  while (heightLeft >= 0) {
		  //alert(heightLeft);
		  position += heightLeft - imgHeight; // top padding for other pages
		  doc.addPage();
		  doc.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
		  doc.addImage(imgData2, 'PNG', 1, pageHeight-8, pageWidth, 0);

		  heightLeft -= pageHeight;
	  }
	  
	  
      var pageHeight2= doc.internal.pageSize.getHeight();
      var pageWidth= doc.internal.pageSize.getWidth();

      var imageHeight = canvas.height; 
      var imageWidth = canvas.width; 
      console.log(document.getElementById("rw").scrollHeight);
      console.log(imageHeight);
      console.log(pageHeight);

      // let elemHeight = this.elementView.nativeElement.offsetHeight;
      // var imgheight = elemHeight * 25.4 / 96; //px to mm
     // var pagecount = Math.ceil(imageHeight / pageHeight);
       var pagecount = 3; 
      /* add initial page */
     // doc.addImage(imgData, 'PNG', 0, 0, pageWidth, 0);
     

      // autoTable(doc, {  
      //   html : "#t1"
      // });
    
      /* add extra pages if the div size is larger than a a4 size */
     // if (pagecount > 0) {
     //     var j = 1;
    //      while (j != pagecount) {
    //          doc.addPage('a4');
     //         doc.addImage(imgData, 'PNG', 0, -(j * pageHeight), pageWidth, 0);
      //        j++;
     //     }
    //  }

for(var j = 1; j <= pagecount;j++){

  doc.setPage(j);
  doc.setFontSize(7);
  doc.text("Page "+String(j)+" of "+ String(pagecount), pageWidth-5, pageHeight-5, null, "right" );
}
 

          
            
        
 	//autoTable(doc,{
		//				html: "#t0",
		//			 didDrawCell: function(data) {
     // if (data.column.index === 0 && data.cell.section === 'body') {
     //    var td = data.cell.raw;
     //    var dim = data.cell.height - data.cell.padding('vertical');
     //    doc.addImage(imgData, 0, 0, dim, dim);
   //   }
   // }
				//	});
				
				



      doc.save("file88.pdf");
	  
	  });
    });
  }

  

	download3(){
		    var doc = new jsPDF('p', 'mm', 'a4');
			html2canvas(document.querySelector("#gc"), {
				  scrollX: 0,
				  scrollY: -window.scrollY
				}).then(canvas => {
					
					//let pageWidth = doc.internal.pageSize.getWidth();
					//let pageHeight= doc.internal.pageSize.getHeight();
					
					
					  let pageWidth = 210 ; 
						let pageHeight = 295; 
					
					
					let imageData = canvas.toDataURL("image/png");
					  var imageHeight = canvas.height; 
					doc.addImage(imageData, 'PNG', 55, 70, pageWidth -4, 0);
					
					doc.setFontSize(10);
					doc.text("Overflow 'ellipsize' (default)", 7, 5);
					
					autoTable(doc,{
						startY: 20,
						html: "#t1",
						columnStyles:{
							0: {
								cellWidth: 50
							},
							1: {
								cellWidth: 50
							}
						}
					});
					
					doc.setFontSize(10);
					
					
					doc.text("Overflow 'hidden'", 7, 57 + 10);


					autoTable(doc,{
						startY: 70 ,
						html: "#t2",
						columnStyles:{
							0: {
								cellWidth: 50
							},
							1: {
								cellWidth: 50
							}
						},
						margin:{
							top:20
						}
					});
					
					autoTable(doc,{
						 startY: 105,
						html: "#t3",
						columnStyles:{
							0: {
								cellWidth: 50
							},
							1: {
								cellWidth: 50
							}
						}
					});
					
					autoTable(doc,{
						 startY: 150,
						html: "#t4",
						columnStyles:{
							0: {
								cellWidth: 10
							},
							1: {
								cellWidth: 20
							},
							2: {
								cellWidth: 20
							},
							3: {
								cellWidth: 50
							}
						}
					});
					
					autoTable(doc,{
						 startY: 350,
						html: "#t5"
					});
					var pagecount = Math.ceil(imageHeight / pageHeight);
					for(var j = 1; j <= pagecount;j++){
					  doc.setPage(j);
					  doc.setFontSize(9);
					  doc.text("Page "+String(j)+" of "+ String(pagecount), pageWidth-5, pageHeight-5, null, "right" );
					}
					doc.save("reports.pdf");
					
					
			});
	}


}
